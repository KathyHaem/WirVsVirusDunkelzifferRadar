export * from './test.service';
import { TestService } from './test.service';
export const APIS = [TestService];
